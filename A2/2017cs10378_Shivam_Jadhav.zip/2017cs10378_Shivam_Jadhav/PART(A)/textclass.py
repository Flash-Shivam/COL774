import csv
import math
import numpy as np
from sklearn.metrics import confusion_matrix
import seaborn as sn
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.metrics import roc_curve, auc

# training.1600000.processed.noemoticon.csv
x = []
filename = "training.1600000.processed.noemoticon.csv"
rows = []
cond = 0
with open(filename, 'r', encoding='ISO-8859-1') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        rows.append(row)


m = len(rows)

y = np.zeros(m,dtype=float)
count = 0
# print("Rows Appended")
di0 = dict()
di1 = dict()
# di2 = dict()
count1 = 0
count2 = 0
z = 0
vocab = []
for i in rows:
    p = (i[5]).split()
    # print(p)
    x.append(p)

    if i[0] == "4":
        for j in p:
            if j in di0:
                di0[j] = di0[j] + 1
            else:
                di0[j] = 1
            vocab.append(j)
        y[z] = 1.0
        z = z + 1
        count = count + 1
        count1 = count1 + len(p)
    else:
        for j in p:
            if j in di1:
                di1[j] = di1[j] + 1
            else:
                di1[j] = 1
            vocab.append(j)
        y[z] = 0.0
        z = z + 1
        count2 = count2 + len(p)


# print(len(di0),len(di1),len(set(vocab)),z)

v = len(set(vocab))
count1 = count1 + v
count2 = count2 + v

phi = float(count)/float(m)
# print(phi,v)


res = np.zeros(m,dtype=float)
q = 0.0

for i in range(0,m):
    n = len(x[i])
    sum1 = 0.0
    sum2 = 0.0
    for j in range(0,n):
        sum1 = sum1 + math.log(di0.get(x[i][j],0)+1) - math.log(count1)
        sum2 = sum2 + math.log(di1.get(x[i][j],0)+1) - math.log(count2)
    sum1 = sum1 + math.log(phi)
    sum2 = sum2 + math.log(1-phi)

    val = max(sum1,sum2)
    if val == sum1:
        res[i] = 1
    else:
        res[i] = 0
    if y[i] == res[i]:
        q = q + 1

# print(res)

print("Accuracy Over Train Data :" , float(100*q)/float(m))
t = 0
filename1 = "testdata.manual.2009.06.14.csv"
rows1 = []
with open(filename1, 'r', encoding='ISO-8859-1') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        if row[0] == "4" or row[0] == "0":
            t = t + 1
            rows1.append(row)

# print(t)

y1 = np.zeros(t,dtype=float)
c = 0
x1 = []
for i in rows1:
    p = (i[5]).split()
    x1.append(p)
    if i[0] == "4":
        y1[c] = 1.0
    elif i[0] == "0":
        y1[c] = 0.0
    c = c+1
y_pred = []

# print(c,len(x1))
q = 0.0
res1 = np.zeros(t,dtype=float)
for i in range(0,t):
    n1 = len(x1[i])
    sum1 = 0.0
    sum2 = 0.0
    for j in range(0,n1):
        sum1 = sum1 + math.log(di0.get(x1[i][j],0)+1) - math.log(count1)
        sum2 = sum2 + math.log(di1.get(x1[i][j],0)+1) - math.log(count2)
    sum1 = sum1 + math.log(phi)
    sum2 = sum2 + math.log(1-phi)
    temp = math.exp(sum1)
    temp1 = math.exp(sum2)
    temp2 = 1/float(temp+temp1)
    temp = temp*float(temp2)
    y_pred.append(temp)
    val = max(sum1,sum2)
    if val == sum1:
        res1[i] = 1
    else:
        res1[i] = 0
    if y1[i] == res1[i]:
        q = q + 1

print("Acurracy Over Test Data :",float(100*q)/float(t))

y_True = []



for i in range(0,t):
    y_True.append(int(y1[i]))
    #y_pred.append(int(res1[i]))
'''
confusionmatrix = confusion_matrix(y_True,y_pred)
print(confusionmatrix)
df_cm = pd.DataFrame(confusionmatrix, index = ['Positive','Negative'],
                  columns = ['Positive','Negative'])
plt.figure(figsize = (10,7))
sn.heatmap(df_cm, annot=True)
plt.show()
'''


fpr, tpr, _ = roc_curve(y_True, y_pred)


roc_auc = auc(fpr, tpr)

# print(roc_auc_score(y_True, y_pred))
plt.figure()
lw = 1
plt.plot(fpr, tpr, color='darkorange',
         lw=lw, label='ROC curve (area = %0.2f)' % roc_auc)
plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
plt.xlim([0.0, 1.0])
plt.ylim([0.0, 1.05])
plt.xlabel('False Positive Rate')
plt.ylabel('True Positive Rate')
plt.title('Receiver operating characteristic example')
plt.legend(loc="lower right")
plt.show()
