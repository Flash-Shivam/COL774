import csv
from cvxopt import matrix
from cvxopt import solvers
import numpy as np
import math
from sklearn.metrics import confusion_matrix

w_list = []
b_list = []
for i in range(0,10):
    for j in range(i+1,10):
        print(i,j)
        class1 = i
        class2 = j
        filename = "train.csv"
        rows = []

        pos = 0
        neg = 0

        with open(filename, 'r') as csvfile:
            csvreader = csv.reader(csvfile)
            for row in csvreader:
                rows.append(row)
                l = len(row)
                index = int(float(row[l-1]))
                if index == class1:
                    pos = pos + 1
                elif index == class2:
                    neg = neg + 1

        n = len(rows[0])-1
        m = pos + neg
        x = np.zeros((m,n),dtype = 'd')
        y = np.zeros(m,dtype='d')
        z = 0
        for i1 in range(0,len(rows)):
            if int(float(rows[i1][784])) == class1 or int(float(rows[i1][784])) == class2:
                y[z] = (int(float(rows[i1][784])) - class1)
                if y[z] == 0:
                    y[z] = -1.0
                else:
                    y[z] = 1.0
                for j1 in range(0,n):
                    x[z, j1] = float(rows[i1][j1])/float(255)
                z = z + 1
        temp = np.zeros((m,m),dtype='d')
        temp1 = np.zeros((2*m,1),dtype='d')
        temp2 = np.zeros((2*m,m),dtype='d')
        temp3 = np.zeros((1,m),dtype='d')
        for i1 in range(0,m):
            temp1[i1, 0] = 1
            temp2[i1, i1] = 1
            temp2[m+i1, i]= -1
            temp3[0, i1] = y[i1]

        gamma = 0.05
        for i1 in range(0,m):
            for j1 in range(0,m):
                res = math.exp(np.sum(np.square(np.add(x[i],-x[j])))*-gamma)
                #res1 = np.dot(x[i1],x[j1])
                # print(res,res1)
                temp[i1, j1] = y[i1]*y[j1]*(res)


        h = matrix((temp1))

        G = matrix(temp2)

        b = matrix(np.array([0.0]))
        q =  matrix(np.ones((m,1),dtype = 'd')*-1)
        A = matrix((temp3))
        P = matrix(temp)
        sol = solvers.qp(P,q,G,h,A,b)
        w = np.zeros((1,n),dtype='d')
        s = 0
        num = 0
        for i1 in sol['x']:
            if not (abs(i1) < 0.0001):
                num = num + 1
            alpha = i1*y[s]
            w = np.add(w,np.dot(x[s],alpha))
            s = s + 1
        w_list.append(w)
        r = 1000000000
        s = -1
        for i1 in range(0,m):
            p = np.dot(w,x[i1])
            if y[i1] == 1:
                if p < r:
                    r = p
            else:
                if p> s:
                    s = p

        b = -(s+r)/2
        b_list.append(b)

def findclass(b_list,w_list,x):
    votes = []
    scores = []
    v = np.zeros(45,dtype='int')
    s = np.zeros(45,dtype='d')
    for i in range(0,len(w_list)):
        resf = np.dot(w_list[i],x) + b_list[i]
        scores.append(resf)
        if resf < 0:
            votes.append(1)

        else:
            votes.append(2)
    z = 0
    for i in range(0,10):
        for j in range(i+1,10):
            v1 = 1/float(1+math.exp(-abs(scores[z])))
            if votes[z] == 1:
                v[i] = v[i] + 1
                s[i] = s[i] + (v1)
                s[j] = s[j] + (1-v1)

            else:
                v[j] = v[j] + 1
                s[i] = s[i] + (1-v1)
                s[j] = s[j] + (v1)
            z = z + 1
    z_max = 0
    for i in range(0,45):
        if v[i] > v[z_max]:
            z_max = i
        elif v[i] == v[z_max] and s[i] > s[z_max]:
            z_max = i

    return z_max



filename = "val.csv"
rows1 = []



with open(filename, 'r') as csvfile:
    csvreader = csv.reader(csvfile)
    for row in csvreader:
        rows1.append(row)
        l = len(row)


n = len(rows1[0])-1
m = len(rows1)
x1 = np.zeros((m,n),dtype = 'd')
y1 = np.zeros(m,dtype='d')

# print(n,m)

z = 0
q = 0.0
y2 = np.zeros(m,dtype='d')
for i in range(0,len(rows1)):

    y1[z] = (int(float(rows1[i][n])))
    for j in range(0,n):
        x1[z, j] = float(rows1[i][j])/float(255)
    y2[z] = findclass(b_list,w_list,x1[z])

    if y1[z] == y2[z]:
        q = q + 1

    z = z + 1
accuracy = float(q)/float(m)

print(accuracy)

y_True = []
y_pred = []
for i in range(0,m):
    y_True.append(int(y1[i]))
    y_pred.append(int(y2[i]))

confusionmatrix = confusion_matrix(y_True,y_pred)
print(confusionmatrix)
df_cm = pd.DataFrame(confusionmatrix, index = ['0','1','2','3','4','5','6','7','8','9'],
                  columns =  ['0','1','2','3','4','5','6','7','8','9'])
plt.figure(figsize = (10,7))
sn.heatmap(df_cm, annot=True)
plt.show()
